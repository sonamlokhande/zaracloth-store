package com.internet.shop.dao.interfaces;

import com.internet.shop.dao.GenericDao;
import com.internet.shop.model.Product;

public interface ProductDao extends GenericDao<Product, Long> {
}
