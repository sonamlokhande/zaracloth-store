package com.internet.shop.service.interfaces;

import com.internet.shop.model.Product;
import com.internet.shop.service.GenericService;

public interface ProductService extends GenericService<Product, Long> {
}
